# DESCARGA DE IMAGENES

Descargar las siguientes imágenes y, una vez descargadas, mostrarlas con la orden correspondiente:

- ubuntu:18.04
- centos:8
- debian:9
- mariadb:latest
- mysql:5.7
- httpd
- tomcat:9.0.39-jdk11
- jenkins/jenkins:lts
- php:7.3-apache

## Requisitos
- Grabacion en asciinema